<?php
session_start(); // Mulai session

// Periksa apakah ada pesanan yang telah diproses
if (!isset($_SESSION['order'])) {
    header('Location: index.php'); // Redirect ke halaman beranda jika tidak ada pesanan
    exit();
}

// Ambil data pesanan
$order = $_SESSION['order'];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Konfirmasi Pemesanan - Toko Peralatan Olahraga</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
        }

        .navbar {
            background-color: #007bff;
        }

        .container {
            max-width: 800px;
            margin-top: 50px;
        }

        .confirmation-summary {
            background-color: white;
            padding: 20px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            margin-top: 30px;
            border-radius: 8px;
        }

        footer {
            background-color: #007bff;
            color: white;
            padding: 15px 0;
        }

        footer p {
            margin: 0;
        }

    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand" href="#">Toko Olahraga</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
    </div>
</nav>

<!-- Konfirmasi Section -->
<section class="container py-5">
    <h2 class="text-center">Konfirmasi Pemesanan</h2>

    <div class="confirmation-summary">
        <h4>Terima kasih, <?= htmlspecialchars($order['name']) ?>!</h4>
        <p>Pemesanan Anda telah berhasil diproses.</p>

        <h5>Detail Pengiriman:</h5>
        <p>Nama: <?= htmlspecialchars($order['name']) ?></p>
        <p>Alamat: <?= nl2br(htmlspecialchars($order['address'])) ?></p>
        <p>Metode Pembayaran: <?= ucfirst($order['payment_method']) ?></p>

        <h5>Daftar Produk yang Dipesan:</h5>
        <ul>
            <?php foreach ($order['cart'] as $item): ?>
                <li>
                    <?= $item['name'] ?> - <?= $item['quantity'] ?> x Rp <?= number_format($item['price'], 0, ',', '.') ?>
                </li>
            <?php endforeach; ?>
        </ul>

        <h4>Total Pembayaran: Rp <?= number_format($order['total_price'], 0, ',', '.') ?></h4>
    </div>
</section>

<!-- Footer -->
<footer class="bg-dark text-white text-center py-3">
    <p>&copy; 2025 Toko Peralatan Olahraga | All Rights Reserved</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
