<?php
session_start(); // Mulai session

// Periksa apakah keranjang sudah ada, jika tidak buat array kosong
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Tangani aksi tambah, kurangi, dan hapus produk
if (isset($_GET['action']) && isset($_GET['id'])) {
    $product_id = $_GET['id'];

    // Cek apakah aksi 'add' untuk menambah produk ke keranjang
    if ($_GET['action'] == 'add') {
        // Mengambil data produk dari query string
        $product_name = $_GET['name'];
        $product_price = $_GET['price'];
        $product_image = $_GET['image'];

        // Jika produk sudah ada di keranjang, tambah kuantitasnya
        if (isset($_SESSION['cart'][$product_id])) {
            $_SESSION['cart'][$product_id]['quantity']++;
        } else {
            // Jika produk belum ada di keranjang, tambah ke keranjang
            $_SESSION['cart'][$product_id] = [
                'name' => $product_name,
                'price' => $product_price,
                'image' => $product_image,
                'quantity' => 1
            ];
        }
    }

    // Cek apakah aksi 'decrease' untuk mengurangi jumlah produk
    if ($_GET['action'] == 'decrease') {
        if (isset($_SESSION['cart'][$product_id]) && $_SESSION['cart'][$product_id]['quantity'] > 1) {
            $_SESSION['cart'][$product_id]['quantity']--;
        } else {
            // Jika kuantitas 1, hapus produk dari keranjang
            unset($_SESSION['cart'][$product_id]);
        }
    }

    // Cek apakah aksi 'remove' untuk menghapus produk dari keranjang
    if ($_GET['action'] == 'remove') {
        unset($_SESSION['cart'][$product_id]);
    }

    // Redirect ke halaman keranjang setelah aksi
    header('Location: keranjang.php');
    exit();
}

// Menghitung total harga
$total_price = 0;
foreach ($_SESSION['cart'] as $item) {
    $total_price += $item['price'] * $item['quantity'];
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Keranjang Belanja - Toko Peralatan Olahraga</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link href="css/keranjang.css" rel="stylesheet">

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand" href="#">Toko Olahraga</a>
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="produk.php">Produk</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="keranjang.php">
                        <i class="fa fa-shopping-cart"></i> Keranjang
                        <span class="badge bg-warning text-dark"><?php echo count($_SESSION['cart']); ?></span>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Keranjang Section -->
<section class="container py-5">
    <h2 class="text-center">Keranjang Belanja</h2>

    <?php if (empty($_SESSION['cart'])): ?>
        <p class="text-center">Keranjang Anda kosong.</p>
    <?php else: ?>
        <div class="row">
            <?php foreach ($_SESSION['cart'] as $product_id => $item): ?>
                <div class="col-md-12 cart-item d-flex align-items-center py-3">
                    <div class="d-flex flex-column flex-md-row w-100">
                        <div class="col-md-2">
                        <img src="<?= file_exists($item['image']) ? $item['image'] : 'img/default_image.jpg' ?>" alt="<?= $item['name'] ?>" class="img-fluid">
                        </div>
                        <div class="col-md-6">
                            <h5 class="product-name"><?= $item['name'] ?></h5>
                            <p class="product-price">Rp <?= number_format($item['price'], 0, ',', '.') ?></p>
                        </div>
                        <div class="col-md-2 quantity-controls">
                            <a href="keranjang.php?action=decrease&id=<?= $product_id ?>" class="btn btn-sm btn-danger">-</a>
                            <input type="text" class="form-control form-control-sm mx-2" value="<?= $item['quantity'] ?>" readonly>
                            <a href="keranjang.php?action=add&id=<?= $product_id ?>&name=<?= urlencode($item['name']) ?>&price=<?= $item['price'] ?>&image=<?= urlencode($item['image']) ?>" class="btn btn-sm btn-success">+</a>
                        </div>
                        <div class="col-md-2 text-end">
                            <p>Rp <?= number_format($item['price'] * $item['quantity'], 0, ',', '.') ?></p>
                            <a href="keranjang.php?action=remove&id=<?= $product_id ?>" class="btn btn-sm btn-danger">Hapus</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>

            <!-- Total Harga -->
            <div class="col-md-12 cart-summary">
                <h4>Total Harga: Rp <?= number_format($total_price, 0, ',', '.') ?></h4>
                <a href="checkout.php" class="btn btn-primary w-100">Lanjutkan Pembelian</a>
            </div>
        </div>
    <?php endif; ?>
</section>

<!-- Footer -->
<footer class="bg-dark text-white text-center py-3">
    <p>&copy; 2025 Toko Peralatan Olahraga | All Rights Reserved</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
