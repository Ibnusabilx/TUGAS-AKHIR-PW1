<?php
session_start();

// Hapus session yang ada
session_unset();
session_destroy();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logout - Sport Star</title>
    <link rel="stylesheet" href="css/logout.css">
</head>
<body>

<div class="logout-container">
    <h2>Anda telah keluar</h2>
    <p>Terima kasih telah mengunjungi kami. Anda telah berhasil keluar dari akun Anda.</p>
    <a href="login.php">
        <button type="button">Kembali ke Login</button>
    </a>
</div>

</body>
</html>
