// script.js
document.addEventListener("DOMContentLoaded", function () {
    const sizeSelect = document.getElementById("size");
    sizeSelect.addEventListener("change", function () {
        if (this.value) {
            alert("Ukuran " + this.value + " dipilih.");
        }
    });
});
document.addEventListener("DOMContentLoaded", function () {
    const sizeSelect = document.getElementById("size");
    const feedbackContainer = document.getElementById("feedback"); // Menampilkan info ukuran terpilih
    const toastContainer = document.querySelector(".toast-container"); // Kontainer untuk toast notification
    const toastMessage = document.querySelector(".toast-message"); // Untuk menampilkan pesan dalam toast

    sizeSelect.addEventListener("change", function () {
        if (this.value) {
            // Menampilkan informasi terkait ukuran yang dipilih
            const selectedSize = this.value;
            feedbackContainer.textContent = "Ukuran yang Anda pilih: " + selectedSize;

            // Menampilkan Toast Notification
            toastMessage.textContent = "Ukuran " + selectedSize + " dipilih!";
            toastContainer.classList.add("show");
            
            // Menghapus toast setelah beberapa detik
            setTimeout(() => {
                toastContainer.classList.remove("show");
            }, 3000);
            
            // Memberikan animasi ke feedback (CSS sudah harus di-setup untuk animasi)
            feedbackContainer.classList.add("animate__animated", "animate__fadeIn");
            setTimeout(() => {
                feedbackContainer.classList.remove("animate__animated", "animate__fadeIn");
            }, 1000); // Hapus animasi setelah selesai
        }
    });
});
