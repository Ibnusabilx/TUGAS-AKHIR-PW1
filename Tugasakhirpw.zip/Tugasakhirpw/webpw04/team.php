<?php include('navbar.php'); ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Toko Peralatan Olahraga - Sport Star</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/team.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>

<!-- About Us Section -->
<section class="about-us-section">
    <h2>Tim Developer Sport Star</h2>

    <div class="container">
        <div class="row">
            <!-- Developer 1 -->
            <div class="col-md-4">
                <div class="team-member">
                    <a href="https://www.instagram.com/oktaftra_/" target="_blank">
                        <img src="img/okta.jpg" alt="Developer 1">
                    </a>
                    <h3>Anggota</h3>
                    <h4>Okta Fitria Ramadhani</h4>
                    <p>0110124119</p>
                    <p>Sehat sehat bumil</p>
                </div>
            </div>

            <!-- Developer 2 -->
            <div class="col-md-4">
                <div class="team-member">
                    <a href="https://www.instagram.com/ib.bill_/" target="_blank">
                        <img src="img/abil.jpg" alt="Developer 2" >
                    </a>
                    <h3>Ketua Kelompok</h3>
                    <h4>Muhammad Ibnu Sabil</h4>
                    <p>0110124006</p>
                    <p>Saya Muhammad Ibnu Sabil selaku ketua kelompok project ini berharap agar mendapat nilai yang maksimal</p>
                </div>
            </div>

            <!-- Developer 3 -->
            <div class="col-md-4">
                <div class="team-member">
                    <a href="https://www.instagram.com/zea_deasminto" target="_blank">
                        <img src="img/zea.jpg" alt="Developer 3">
                    </a>
                    <h3>Anggota</h3>
                    <h4>Fariza Zea De Asminto</h4>
                    <p>0110124207</p>
                    <p>Sehat sehat orang baik</p>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include('footer.php'); ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
