<?php
// index.php
include('header.php');
?>

<!-- Tujuan Website -->
<section class="about-section container">
    <h2 class="text-center">Tujuan Kami</h2>
    <p>Toko Olahraga adalah platform yang diciptakan untuk menyediakan berbagai peralatan olahraga berkualitas tinggi. Kami percaya bahwa olahraga adalah salah satu cara terbaik untuk menjaga kesehatan dan kebugaran tubuh. Oleh karena itu, kami ingin mempermudah Anda dalam menemukan dan membeli peralatan olahraga yang sesuai dengan kebutuhan Anda.</p>
    <p>Dengan berbagai pilihan produk yang kami tawarkan, kami bertujuan untuk memberikan kenyamanan berbelanja online, mulai dari sepatu olahraga, pakaian, hingga peralatan fitness. Semua produk yang kami jual dijamin kualitasnya dan akan membantu Anda mencapai tujuan kebugaran Anda, apakah itu untuk berolahraga di rumah atau di luar ruangan.</p>
    <p>Kami juga menyediakan panduan ukuran yang lengkap agar Anda bisa memilih produk yang paling cocok untuk Anda. Nikmati pengalaman berbelanja yang mudah dan menyenangkan di Toko Olahraga kami!</p>
</section>

<!-- Follow Us Section -->
<section class="follow-us-section container py-5">
    <h2 class="text-center mb-4">Follow Us</h2>
    <div class="text-center">
        <a href="https://www.instagram.com" target="_blank" class="btn btn-outline-light btn-lg mx-2">
            <i class="fab fa-instagram"></i> Instagram
        </a>
        <a href="https://www.tiktok.com" target="_blank" class="btn btn-outline-light btn-lg mx-2">
            <i class="fab fa-tiktok"></i> TikTok
        </a>
        <a href="https://www.twitter.com" target="_blank" class="btn btn-outline-light btn-lg mx-2">
            <i class="fab fa-twitter"></i> Twitter
        </a>
    </div>
</section>

<!-- Produk Unggulan -->
<section class="container py-5">
    <h2 class="text-center mb-4">Produk Unggulan</h2>
    <div class="row">
        <!-- Card Produk -->
        <div class="col-md-4 mb-4">
            <div class="card product-card">
                <img src="img/bola basket.jpg" class="card-img-top" alt="Bola Basket">
                <div class="card-body">
                    <h5 class="card-title">Bola Basket</h5>
                    <p class="card-text">Bola basket berkualitas tinggi untuk latihan atau pertandingan.</p>
                    <a href="produk.php" class="btn btn-primary">Lihat Detail</a>
                </div>
            </div>
        </div>
        <!-- Card Produk -->
        <div class="col-md-4 mb-4">
            <div class="card product-card">
                <img src="img/bola sepak.jpg" class="card-img-top" alt="Bola Sepak">
                <div class="card-body">
                    <h5 class="card-title">Bola Sepak</h5>
                    <p class="card-text">Bola sepak untuk latihan atau pertandingan.</p>
                    <a href="produk.php" class="btn btn-primary">Lihat Detail</a>
                </div>
            </div>
        </div>
        <!-- Card Produk -->
        <div class="col-md-4 mb-4">
            <div class="card product-card">
                <img src="img/barbel.jpg" class="card-img-top" alt="Barbel Set">
                <div class="card-body">
                    <h5 class="card-title">Barbel Set</h5>
                    <p class="card-text">Peralatan fitness untuk latihan di rumah.</p>
                    <a href="produk.php" class="btn btn-primary">Lihat Detail</a>
                </div>
            </div>
        </div>
    </div>
</section>

<?php
include('footer.php');
?>
