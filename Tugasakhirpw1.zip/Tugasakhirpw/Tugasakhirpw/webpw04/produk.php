<?php
session_start(); // Mulai session

// Daftar produk yang tersedia
$produk = [
    ['name' => 'Bola Basket', 'description' => 'Bola basket berkualitas tinggi.', 'image' => 'img/bola basket.jpg', 'price' => 300000],
    ['name' => 'Bola Sepak', 'description' => 'Bola sepak untuk latihan atau pertandingan.', 'image' => 'img/bola sepak.jpg', 'price' => 250000],
    ['name' => 'Bola Tennis', 'description' => 'Bola tennis untuk bermain di lapangan.', 'image' => 'img/bola tennis.jpg', 'price' => 150000],
    ['name' => 'Barbel Set', 'description' => 'Peralatan fitness untuk di rumah.', 'image' => 'img/barbel.jpg', 'price' => 400000],
    ['name' => 'Handgrip', 'description' => 'Peralatan untuk melatih kekuatan genggaman.', 'image' => 'img/handgrip.jpg', 'price' => 50000],
    ['name' => 'Pullup Bar', 'description' => 'Peralatan untuk pull-up dan latihan di rumah.', 'image' => 'img/pullup bar.jpg', 'price' => 350000],
    ['name' => 'Matras Yoga', 'description' => 'Matras yoga untuk latihan yoga dan meditasi.', 'image' => 'img/matras yoga.jpg', 'price' => 100000],
    ['name' => 'Sarung Tinju', 'description' => 'Sarung tinju untuk latihan dan pertandingan.', 'image' => 'img/sarung tinju.jpg', 'price' => 150000],
    ['name' => 'Jump Rope', 'description' => 'Tali skipping untuk latihan kebugaran.', 'image' => 'img/jump rope.jpg', 'price' => 75000],
];

// Ambil query pencarian dari URL jika ada
$search_query = isset($_GET['search_query']) ? $_GET['search_query'] : '';

// Filter produk berdasarkan query pencarian
$filtered_products = [];
if ($search_query) {
    foreach ($produk as $item) {
        if (stripos($item['name'], $search_query) !== false || stripos($item['description'], $search_query) !== false) {
            $filtered_products[] = $item;
        }
    }
} else {
    $filtered_products = $produk;
}

// Menambahkan produk ke keranjang
if (isset($_GET['action']) && $_GET['action'] == 'add' && isset($_GET['id'])) {
    $product_id = $_GET['id'];
    
    // Jika produk ada dalam daftar
    foreach ($produk as $key => $item) {
        if ($key == $product_id) {
            // Jika produk sudah ada dalam keranjang, tambah jumlahnya
            if (isset($_SESSION['cart'][$product_id])) {
                $_SESSION['cart'][$product_id]['quantity']++;
            } else {
                // Jika produk belum ada di keranjang, tambahkan
                $_SESSION['cart'][$product_id] = [
                    'name' => $item['name'],
                    'price' => $item['price'],
                    'quantity' => 1,
                    'image' => $item['image'] // Menambahkan path gambar
                ];
            }
            break;
        }
    }
    
    // Redirect kembali ke halaman produk
    header('Location: produk.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Produk - Toko Peralatan Olahraga</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/produk.css"> <!-- Link ke file CSS eksternal -->
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand" href="#">Sport Star</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Beranda</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="produk.php">Produk</a>
                </li>
            </ul>
        </div>
    </div>

    <!-- Gabungkan Search Bar dan Keranjang dalam satu container d-flex -->
    <div class="container d-flex justify-content-center align-items-center">
        <!-- Search Bar -->
        <form method="get" action="produk.php" class="d-flex w-50">
            <input type="text" name="search_query" class="form-control me-2" placeholder="Cari produk..." value="<?= htmlspecialchars($search_query) ?>">
            <button type="submit" class="btn btn-success">Cari</button>
        </form>
        
        <!-- Ikon Keranjang di sebelah kanan search bar -->
        <a href="keranjang.php" class="ms-3 d-flex align-items-center text-decoration-none">
            <i class="fa fa-shopping-cart text-white"></i>
            <span class="badge bg-warning text-dark ms-2"><?= count($_SESSION['cart'] ?? []); ?></span>
        </a>
    </div>
</nav>

<!-- Produk Section -->
<section class="container py-5">
    <h2 class="text-center mb-4">Produk Kami</h2>
    <div class="row">
        <?php if (count($filtered_products) > 0): ?>
            <?php foreach ($filtered_products as $key => $item): ?>
                <div class="col-md-4 mb-4">
                    <div class="card product-card">
                        <img src="<?= file_exists($item['image']) ? $item['image'] : 'img/default_image.jpg' ?>" class="card-img-top" alt="<?= $item['name'] ?>">
                        <div class="card-body">
                            <h5 class="card-title"><?= $item['name'] ?></h5>
                            <p class="card-text"><?= $item['description'] ?></p>
                            <p class="card-text">Rp <?= number_format($item['price'], 0, ',', '.') ?></p>
                            <a href="produk.php?action=add&id=<?= $key ?>" class="btn btn-success">Tambah ke Keranjang</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p class="text-center">Tidak ada produk yang cocok dengan pencarian Anda.</p>
        <?php endif; ?>
    </div>
</section>

<!-- Footer -->
<footer class="bg-dark text-white text-center py-3">
    <p>&copy; 2025 Toko Peralatan Olahraga | All Rights Reserved</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
