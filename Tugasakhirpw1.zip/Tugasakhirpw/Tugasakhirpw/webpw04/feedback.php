<!-- Feedback Info -->
<div id="feedback" class="feedback-info">
    <?php 
    // Menampilkan pesan feedback dinamis
    echo "Pesan feedback yang dinamis bisa ditampilkan di sini!";
    ?>
</div>

<!-- Toast Notification -->
<div class="toast-container position-fixed bottom-0 end-0 p-3">
    <div id="toast" class="toast">
        <div class="toast-header">
            <strong class="me-auto">Pemberitahuan</strong>
            <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
        <div class="toast-body">
            <?php 
            // Menampilkan pesan dinamis dalam toast
            echo "Ukuran yang dipilih: " . (isset($_POST['size']) ? $_POST['size'] : "Tidak ada ukuran yang dipilih.");
            ?>
        </div>
    </div>
</div>
