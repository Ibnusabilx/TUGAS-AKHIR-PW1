<?php
// about.php
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - Sport Star</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/header.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>

<!-- Memasukkan navbar menggunakan PHP -->
<?php include('navbar.php'); ?>

<!-- Tujuan Website -->
<section class="about-section container">
    <h2 class="text-center">Tujuan Kami</h2>
    <p>Toko Olahraga adalah platform yang diciptakan untuk menyediakan berbagai peralatan olahraga berkualitas tinggi. Kami percaya bahwa olahraga adalah salah satu cara terbaik untuk menjaga kesehatan dan kebugaran tubuh. Oleh karena itu, kami ingin mempermudah Anda dalam menemukan dan membeli peralatan olahraga yang sesuai dengan kebutuhan Anda.</p>
    <p>Dengan berbagai pilihan produk yang kami tawarkan, kami bertujuan untuk memberikan kenyamanan berbelanja online, mulai dari sepatu olahraga, pakaian, hingga peralatan fitness. Semua produk yang kami jual dijamin kualitasnya dan akan membantu Anda mencapai tujuan kebugaran Anda, apakah itu untuk berolahraga di rumah atau di luar ruangan.</p>
    <p>Kami juga menyediakan panduan ukuran yang lengkap agar Anda bisa memilih produk yang paling cocok untuk Anda. Nikmati pengalaman berbelanja yang mudah dan menyenangkan di Toko Olahraga kami!</p>
</section>
<!-- Memasukkan footer menggunakan PHP -->
<?php include('footer.php'); ?>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
<script src="script.js"></script>

</body>
</html>
