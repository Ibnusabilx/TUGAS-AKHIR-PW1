<?php
session_start(); // Mulai session

// Periksa apakah keranjang sudah ada, jika tidak buat array kosong
if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    header('Location: keranjang.php'); // Jika keranjang kosong, redirect ke keranjang
    exit();
}

// Menghitung total harga
$total_price = 0;
foreach ($_SESSION['cart'] as $item) {
    $total_price += $item['price'] * $item['quantity'];
}

// Proses checkout (misalnya, mengambil data pengiriman)
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ambil data dari form
    $name = $_POST['name'];
    $address = $_POST['address'];
    $payment_method = $_POST['payment_method'];

    // Simulasi proses checkout (misalnya, menyimpan pesanan ke database)
    // Di sini, kita hanya menampilkan informasi yang dimasukkan
    $_SESSION['order'] = [
        'name' => $name,
        'address' => $address,
        'payment_method' => $payment_method,
        'total_price' => $total_price,
        'cart' => $_SESSION['cart']
    ];

    // Hapus keranjang setelah checkout
    unset($_SESSION['cart']);

    // Redirect ke halaman konfirmasi pesanan
    header('Location: konfirmasi.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - Toko Peralatan Olahraga</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/checkout.css"> <!-- Link ke file CSS eksternal -->
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand" href="#">Toko Olahraga</a>
    </div>
</nav>

<!-- Checkout Section -->
<section class="container py-5">
    <h2 class="text-center">Checkout</h2>

    <form action="checkout.php" method="POST">
        <div class="mb-3">
            <label for="name" class="form-label">Nama Lengkap</label>
            <input type="text" class="form-control" id="name" name="name" required>
        </div>
        <div class="mb-3">
            <label for="address" class="form-label">Alamat Pengiriman</label>
            <textarea class="form-control" id="address" name="address" rows="3" required></textarea>
        </div>
        <div class="mb-3">
            <label for="payment_method" class="form-label">Metode Pembayaran</label>
            <select class="form-control" id="payment_method" name="payment_method" required>
                <option value="transfer">Transfer Bank</option>
                <option value="cod">Cash On Delivery</option>
            </select>
        </div>

        <!-- Checkout Summary -->
        <div class="checkout-summary">
            <h4>Total Harga: Rp <?= number_format($total_price, 0, ',', '.') ?></h4>
            <button type="submit" class="btn btn-success w-100">Proses Pembayaran</button>
        </div>
    </form>
</section>

<!-- Footer -->
<footer class="bg-dark text-white text-center py-3">
    <p>&copy; 2025 Toko Peralatan Olahraga | All Rights Reserved</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
