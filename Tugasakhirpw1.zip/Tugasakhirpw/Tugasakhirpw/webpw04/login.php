<?php
session_start();

// Jika pengguna sudah login, arahkan ke halaman utama
if (isset($_SESSION['username'])) {
    header("Location: index.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ambil username dan password yang dimasukkan
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Cek kredensial (di sini kita hanya menggunakan contoh sederhana)
    if ($username == 'admin' && $password == 'password123') {
        $_SESSION['username'] = $username;  // Menyimpan session
        header("Location: index.php"); // Arahkan ke halaman utama setelah login sukses
        exit();
    } else {
        $error_message = "Username atau Password salah!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="css/login.css">
</head>
<body>
    <div class="login-container">
        <h2 class="text-center">Login</h2>

        <?php
        if (isset($error_message)) {
            echo "<div class='error-message'>{$error_message}</div>";
        }
        ?>

        <form action="login.php" method="POST" class="login-form">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" class="form-control" required>
            </div>

            <div class="form-group">
                <button type="submit" class="btn btn-primary">Login</button>
            </div>

            <div>
            <a class="nav-link" href="index.php">Home</a>
            </div>

            <p class="text-center">
                Belum punya akun? <a href="register.php">Daftar di sini</a>
            </p>
        </form>
    </div>
</body>
</html>
